#!/usr/bin/perl -w
use strict;
use File::Copy;
use Archive::Zip qw/:ERROR_CODES :CONSTANTS/;

#VARIABLE INITIALIZATION
my $template_in_path = "";

$template_in_path = $ARGV[0];
chomp($template_in_path);

$template_in_path=~s|\\|/|gs;

my $exepath = $0;
if($exepath=~m/\\/s)
{
	$exepath=~s/(.*)\\(.*)/$1/s;
}
else
{
	$exepath = ".";
}

unlink("$exepath\\out-error.xml");
open (OUT_ERROR, '>>', "$exepath\\out-error.xml") or die "\nE005 Error: could not write in out-error.xml file$!\n";

undef($/);
###### TEMPLATE.XML ######
my $_IN_TEMPLATE = "";
open (IN_TEMPLATE, '<', "$template_in_path") or die "\n000 Error: could not open template.xml file$!\n";
$_IN_TEMPLATE=<IN_TEMPLATE>;
close(IN_TEMPLATE);
###############################
#ispan
my $entity_file_path = "";

if($_IN_TEMPLATE=~m/<entity_file path=\"([^>]+)\"/s)
{
	$entity_file_path = $1;
	$entity_file_path=~s|\\|/|gs;
}

my $_IN_ENTITY_CONTENT = "";

open (IN_ENTITY_CONTENT, '<', "$entity_file_path") or die "\n000 Error: could not open ENTITY FILE file$!\n";
$_IN_ENTITY_CONTENT=<IN_ENTITY_CONTENT>;
close(IN_ENTITY_CONTENT);


#OPENING ONE BY ONE ASSET FILE

my $asset_id = "";
my $asset_content = "";
my $_IN_HTM_FILE = "";
my $_IN_CSS_FILE = "";

print "\n- - - - - - - - - - - - -\n\n";
while($_IN_TEMPLATE=~/<asset id=\"([^"]+)\">(.*?)<\/asset>/s)
{
	 $asset_id = $1;
	 $asset_content = $2;
	 my $input_path = "";
	 my $input_file = "";
	 my $input_css = "";	
	 my $output_path = "";
	 $input_path = $1 if($asset_content=~m/<input_path value=\"([^"]+)\"/is);
	 $input_path=~s|\\|/|gs;
	 $input_file = $1 if($asset_content=~m/<input_file value=\"([^"]+)\"/is);
	 $input_css = $1 if($asset_content=~m/<input_css value=\"([^"]+)\"/is);
	 $output_path = $1 if($asset_content=~m/<outpur_path value=\"([^"]+)\"/is);
	 $output_path=~s|\\|/|gs;

	 my $input_css_with_path = "";
	 my $input_file_with_path = "";
	 my $output_file_with_path = "";
	 my $inout_temp_with_path_01 = "";
	 my $inout_temp_with_path_02 = "";
	 my $inout_temp_with_path_03 = "";


    ###########-START IN CSS FILE ########################
	 $input_css_with_path = "$input_path/$input_css";
	 open (IN_CSS_FILE, '<', "$input_css_with_path") or die "Error: could not open css FILE $input_css_with_path$!\n";
	 $_IN_CSS_FILE = <IN_CSS_FILE>;
	 close(IN_CSS_FILE);

	 $_IN_CSS_FILE=~s|font-family\: \"([^"]+)\"\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-weight\: normal\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-variant\: normal\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-style\: normal\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-size\: ([^;]+)\;\n?||igs;
	 $_IN_CSS_FILE=~s|line-height\: ([^;]+)\;\n?||igs;
	 $_IN_CSS_FILE=~s|color: \#|color: |igs;

	 $_IN_CSS_FILE=~s|font-family \: \"([^"]+)\"\;\n?||igs;
 	 $_IN_CSS_FILE=~s|font-variant \: normal\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-weight \: normal\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-style \: normal\;\n?||igs;
	 $_IN_CSS_FILE=~s|font-size \: ([^;]+)\;\n?||igs;
	 $_IN_CSS_FILE=~s|line-height \: ([^;]+)\;\n?||igs;
	 $_IN_CSS_FILE=~s|color \: \#|color \: |igs;


	 #$_IN_CSS_FILE=~s|\{|<start>|igs;
	 #$_IN_CSS_FILE=~s|\}|<\/start>|igs;
    ###########-END IN CSS FILE ########################	 


	 $input_file_with_path = "$input_path/$input_file";
	 $output_file_with_path = "$output_path/$input_file";
	 $inout_temp_with_path_01 = "$input_path/${input_file}_TMP01";
	 $inout_temp_with_path_02 = "$input_path/${input_file}_TMP02";
	 $inout_temp_with_path_03 = "$input_path/${input_file}_TMP03";
	######################################## STEP 001 #######################################################

    ###########-START- IN SOURCE.HTML AND OUT TMP01 ########################
 	open (IN_HTM_FILE, '<', "$input_file_with_path") or die "Error: could not open SOURCE HTML FILE $input_file_with_path$!\n";
	$_IN_HTM_FILE = <IN_HTM_FILE>;
	close(IN_HTM_FILE);

	print "Processing on file: $input_file\n";
	print OUT_ERROR "\nProcessing on file:-------- $input_file\n\n";

	#START ENTITY REPLACEMENT
	my $utf8 = "";
	my $unicode = "";
	while($_IN_ENTITY_CONTENT=~m/<entity find=\"([^"]+)\" replace=\"([^"]+)\"/is)
	{
		$utf8 = $1;
		$unicode = $2;
		$_IN_HTM_FILE=~s|$utf8|$unicode|gs;
		
		$_IN_ENTITY_CONTENT=~s|<entity|<123entity|is;
	}
	$_IN_ENTITY_CONTENT=~s|<123entity|<entity|igs;
	#END ENTITY REPLACEMENT

	#START SPAN LABELING

	my $span = 0;
	while($_IN_HTM_FILE=~m/<(\/)?span\s?[^>]*?>/si)
	{
		my $slash = $1;
		if((!defined $slash) || ($slash eq ''))
		{
			$span++;
			$_IN_HTM_FILE=~s/<span(\s?[^>]*?)>/<ap123span_${span}$1>/si;
		}
		else
		{
			$_IN_HTM_FILE=~s/<(\/)?span(\s?[^>]*?)>/<ap123${1}span_${span}$2>/si;
			$span--;
		}
	}
	$_IN_HTM_FILE=~s/<ap123/</gs;
	#END SPAN LABELING

	#OUT TMP01
	open (OUT_TMP01, '>', "$inout_temp_with_path_01") or die "Error: could not out file $inout_temp_with_path_01$!\n";
	print OUT_TMP01 "$_IN_HTM_FILE";
	close(OUT_TMP01);
	###########-END- IN SOURCE.HTML AND OUT TMP01 ########################



	######################################## STEP 002 #######################################################

	###########-START- IN TMP01 OUT TMP02 ########################
	my $_IN_TMP01 = "";
 	open (IN_TMP01, '<', "$inout_temp_with_path_01") or die "Error: could not open TMP 01 $inout_temp_with_path_01$!\n";
	$_IN_TMP01 = <IN_TMP01>;
	close(IN_TMP01);

	##process span class attribute
	#span_4
	my $span_4_attribute = "";
	my @span_4_array = "";
	my $span_4_data = "";

	while($_IN_TMP01=~m/<span_4 ([^>]+)>(.*?)<\/span_4>/is)
	{
		$span_4_attribute = $1;
		$span_4_data = $2;
		if($span_4_attribute=~m/math/is)
		{

			$_IN_TMP01=~s/<span_4 ([^>]+)>(.*?)<\/span_4>/<vpromath $span_4_attribute>$span_4_data<\/vpromath>/is;

		}
		else
		{
			my $new_4_element = "";
			my $span_4_data_for_out_error = "";
			$span_4_data_for_out_error = $1 if($span_4_data=~m/([<\w]+)/is);
			my $span_4_class_attrib = "";
			$span_4_class_attrib = $1 if($span_4_attribute=~m/class=\"([^"]+)\"/is);
			@span_4_array = split(' ', $span_4_class_attrib);
			foreach my $each_class_4 (@span_4_array)
			{
				my $css_file_class_atrib_span_4 = "";
				if($_IN_CSS_FILE=~m/\.$each_class_4 \{(.*?)\}/is)
				{
					$css_file_class_atrib_span_4 = $1;
					my $span_attribute_value_4 = "";
					while($_IN_TEMPLATE=~m/<span_attribute value=\"([^"]+)\"/is)
					{
						$span_attribute_value_4 = $1;
						if($css_file_class_atrib_span_4=~m/$span_attribute_value_4 ([^;]+)\;/is)
						{
							$new_4_element = $new_4_element.$1;
						}
						$_IN_TEMPLATE=~s|<span_attribute|<1234span_attribute|is;
					}
					$_IN_TEMPLATE=~s|<1234span_attribute|<span_attribute|igs;
				}
			}

		$_IN_TMP01=~s/<span_4 ([^>]+)>(.*?)<\/span_4>/<vpro_$new_4_element>$span_4_data<\/vpro_$new_4_element>/is;
		#print OUT_ERROR "<span $span_4_attribute>$span_4_data_for_out_error\t<vpro_$new_4_element>\n";
		}	
	}
	#span_4

	#span_3
	my $span_3_attribute = "";
	my @span_3_array = "";
	my $span_3_data = "";

	while($_IN_TMP01=~m/<span_3 ([^>]+)>(.*?)<\/span_3>/is)
	{
		$span_3_attribute = $1;
		$span_3_data = $2;
		if($span_3_attribute=~m/math/is)
		{

			$_IN_TMP01=~s/<span_3 ([^>]+)>(.*?)<\/span_3>/<vpromath $span_3_attribute>$span_3_data<\/vpromath>/is;

		}
		else
		{
			my $new_3_element = "";
			my $span_3_data_for_out_error = "";
			$span_3_data_for_out_error = $1 if($span_3_data=~m/([<\w]+)/is);
			my $span_3_class_attrib = "";
			$span_3_class_attrib = $1 if($span_3_attribute=~m/class=\"([^"]+)\"/is);
			@span_3_array = split(' ', $span_3_class_attrib);
			foreach my $each_class_3 (@span_3_array)
			{
				my $css_file_class_atrib_span_3 = "";
				if($_IN_CSS_FILE=~m/\.$each_class_3 \{(.*?)\}/is)
				{
					$css_file_class_atrib_span_3 = $1;
					my $span_attribute_value_3 = "";
					while($_IN_TEMPLATE=~m/<span_attribute value=\"([^"]+)\"/is)
					{
						$span_attribute_value_3 = $1;
						if($css_file_class_atrib_span_3=~m/$span_attribute_value_3 ([^;]+)\;/is)
						{
							$new_3_element = $new_3_element.$1;
						}
						$_IN_TEMPLATE=~s|<span_attribute|<1234span_attribute|is;
					}
					$_IN_TEMPLATE=~s|<1234span_attribute|<span_attribute|igs;
				}
			}

		$_IN_TMP01=~s/<span_3 ([^>]+)>(.*?)<\/span_3>/<vpro_$new_3_element>$span_3_data<\/vpro_$new_3_element>/is;
		#print OUT_ERROR "<span $span_3_attribute>$span_3_data_for_out_error\t<vpro_$new_3_element>\n";
		}	
	}
	#span_3

	#span_2
	my $span_2_attribute = "";
	my @span_2_array = "";
	my $span_2_data = "";

	while($_IN_TMP01=~m/<span_2 ([^>]+)>(.*?)<\/span_2>/is)
	{
		$span_2_attribute = $1;
		$span_2_data = $2;
		if($span_2_attribute=~m/math/is)
		{

			$_IN_TMP01=~s/<span_2 ([^>]+)>(.*?)<\/span_2>/<vpromath $span_2_attribute>$span_2_data<\/vpromath>/is;

		}
		else
		{
			my $new_2_element = "";
			my $span_2_data_for_out_error = "";
			$span_2_data_for_out_error = $1 if($span_2_data=~m/([<\w]+)/is);
			my $span_2_class_attrib = "";
			$span_2_class_attrib = $1 if($span_2_attribute=~m/class=\"([^"]+)\"/is);
			@span_2_array = split(' ', $span_2_class_attrib);
			foreach my $each_class_2 (@span_2_array)
			{
				my $css_file_class_atrib_span_2 = "";
				if($_IN_CSS_FILE=~m/\.$each_class_2 \{(.*?)\}/is)
				{
					$css_file_class_atrib_span_2 = $1;
					my $span_attribute_value_2 = "";
					while($_IN_TEMPLATE=~m/<span_attribute value=\"([^"]+)\"/is)
					{
						$span_attribute_value_2 = $1;
						if($css_file_class_atrib_span_2=~m/$span_attribute_value_2 ([^;]+)\;/is)
						{
							$new_2_element = $new_2_element.$1;
						}
						$_IN_TEMPLATE=~s|<span_attribute|<1234span_attribute|is;
					}
					$_IN_TEMPLATE=~s|<1234span_attribute|<span_attribute|igs;
				}
			}

		$_IN_TMP01=~s/<span_2 ([^>]+)>(.*?)<\/span_2>/<vpro_$new_2_element>$span_2_data<\/vpro_$new_2_element>/is;
		#print OUT_ERROR "<span $span_2_attribute>$span_2_data_for_out_error\t<vpro_$new_2_element>\n";
		}	
	}
	#span_2


	#span_1
	my $span_1_attribute = "";
	my @span_1_array = "";
	my $span_1_data = "";

	while($_IN_TMP01=~m/<span_1 ([^>]+)>(.*?)<\/span_1>/is)
	{
		$span_1_attribute = $1;
		$span_1_data = $2;
		if($span_1_attribute=~m/math/is)
		{

			$_IN_TMP01=~s/<span_1 ([^>]+)>(.*?)<\/span_1>/<vpromath $span_1_attribute>$span_1_data<\/vpromath>/is;

		}
		else
		{
			my $new_1_element = "";
			my $span_1_data_for_out_error = "";
			$span_1_data_for_out_error = $1 if($span_1_data=~m/([<\w]+)/is);
			my $span_1_class_attrib = "";
			$span_1_class_attrib = $1 if($span_1_attribute=~m/class=\"([^"]+)\"/is);



			if($span_1_class_attrib=~m/(\s)/is)
			{
				@span_1_array = split(' ', $span_1_class_attrib);
			}
			else
			{
				@span_1_array = "$span_1_class_attrib";
			}

			foreach my $each_class_1 (@span_1_array)
			{
				my $css_file_class_atrib_span_1 = "";
				if($_IN_CSS_FILE=~m/\.$each_class_1 \{(.*?)\}/is)
				{
					$css_file_class_atrib_span_1 = $1;
					my $span_attribute_value_1 = "";
					while($_IN_TEMPLATE=~m/<span_attribute value=\"([^"]+)\"/is)
					{
						$span_attribute_value_1 = $1;
						if($css_file_class_atrib_span_1=~m/$span_attribute_value_1 ([^;]+)\;/is)
						{
							$new_1_element = $new_1_element.$1;
						}
						$_IN_TEMPLATE=~s|<span_attribute|<1234span_attribute|is;
					}
					$_IN_TEMPLATE=~s|<1234span_attribute|<span_attribute|igs;
				}
			}

		$_IN_TMP01=~s/<span_1 ([^>]+)>(.*?)<\/span_1>/<vpro_$new_1_element>$span_1_data<\/vpro_$new_1_element>/is;
		#print OUT_ERROR "<span $span_1_attribute>$span_1_data_for_out_error\t<vpro_$new_1_element>\n";
		}	
	}
	#span_1

	$_IN_TMP01=~s|<vpro_>||igs;
	$_IN_TMP01=~s|<\/vpro_>||igs;



	#OUT TMP02
	open (OUT_TMP02, '>', "$inout_temp_with_path_02") or die "Error: could not out TEMP 2 file $inout_temp_with_path_02$!\n";
	print OUT_TMP02 "$_IN_TMP01";
	close(OUT_TMP02);
	###########-END- IN TMP01 OUT TMP02 ########################



	######################################## STEP 003 #######################################################
	
	###########-START- IN TMP02 OUT TMP03 ########################
	my $_IN_TMP02 = "";
 	open (IN_TMP02, '<', "$inout_temp_with_path_02") or die "Error: could not open TMP 02 $inout_temp_with_path_02$!\n";
	$_IN_TMP02 = <IN_TMP02>;
	close(IN_TMP02);
	#final clineup
	$_IN_TMP02=~s|\t| |igs;
	$_IN_TMP02=~s|  | |igs;
	$_IN_TMP02=~s|<\/([^>]+)><\1>||igs;
	$_IN_TMP02=~s|<\/([^>]+)> <\1>| |igs;
	$_IN_TMP02=~s|<vpro_([^>]+)> <\/vpro_\1>| |igs;
	$_IN_TMP02=~s|<vpro_([^>]+)> | <vpro_$1>|igs;
	$_IN_TMP02=~s| <\/vpro_([^>]+)>|<\/vpro_$1> |igs;
	$_IN_TMP02=~s|<vpro_([^>]+)> | <vpro_$1>|igs;
	$_IN_TMP02=~s| <\/vpro_([^>]+)>|<\/vpro_$1> |igs;
	$_IN_TMP02=~s|\n([\s]+)|\n|igs;
	$_IN_TMP02=~s|([a-zA-Z])\&\#x2019\;([a-zA-Z])|$1\&\#x0027\;$2|gs;
	$_IN_TMP02=~s|<vpro_italic>|<em>|igs;
	$_IN_TMP02=~s|</vpro_italic>|</em>|igs;
	$_IN_TMP02=~s|<vpro_sub>|<sub>|igs;
	$_IN_TMP02=~s|</vpro_sub>|</sub>|igs;
	$_IN_TMP02=~s|<vpro_sup>|<sup>|igs;
	$_IN_TMP02=~s|</vpro_sup>|</sup>|igs;
	$_IN_TMP02=~s|<vpro_super>|<sup>|igs;
	$_IN_TMP02=~s|</vpro_super>|</sup>|igs;
	$_IN_TMP02=~s|<vpro_bold>|<bold>|igs;
	$_IN_TMP02=~s|</vpro_bold>|</bold>|igs;
	$_IN_TMP02=~s|<vpromath ([^>]+)><\/vpromath>||igs;
	$_IN_TMP02=~s|<vpromath ([^>]+)> <\/vpromath>| |igs;
	$_IN_TMP02=~s|<p ([^>]+)> |<p $1>|igs;
	$_IN_TMP02=~s| <\/p>|<\/p>|igs;
	$_IN_TMP02=~s|<li ([^>]+)> |<li $1>|igs;
	$_IN_TMP02=~s| <\/li>|<\/li>|igs;


	#mathprocess
	$_IN_TMP02=~s|<vpromath ([^>]+)> | <vpromath $1>|igs;
	$_IN_TMP02=~s| </vpromath>|</vpromath> |igs;
	$_IN_TMP02=~s|<vpromath ([^>]+)>5</vpromath>|=|igs;
	$_IN_TMP02=~s|<vpromath ([^>]+)>1</vpromath>|\+|igs;
	$_IN_TMP02=~s|<vpromath ([^>]+)>2</vpromath>|\&\#x2013\;|igs;
	$_IN_TMP02=~s|<vpromath ([^>]+)>3</vpromath>|\&\#x00D7\;|igs;


	#OUT TMP03
	open (OUT_TMP03, '>', "$inout_temp_with_path_03") or die "Error: could not out TEMP 3 file $inout_temp_with_path_03$!\n";
	print OUT_TMP03 "$_IN_TMP02";
	close(OUT_TMP03);
	###########-END- IN TMP02 OUT TMP03 ########################


	###########-START- IN TMP03 OUT FINAL ########################
	my $_IN_TMP03 = "";
 	open (IN_TMP03, '<', "$inout_temp_with_path_03") or die "Error: could not open TMP 03 $inout_temp_with_path_03$!\n";
	$_IN_TMP03 = <IN_TMP03>;
	close(IN_TMP03);

	
	##process in temp file 3

	my $p_attribute = "";
	while($_IN_TMP03=~m/<p ([^>]+)>/is)
	{
		$p_attribute = $1;
		
		$p_attribute=~s| xml:lang=\"([^"]+)\"||igs;
		$p_attribute=~s|class=\"(.*?) ([^"]+)\"|class=\"$1"|igs;

		$_IN_TMP03=~s|<p ([^>]+)>|<123p $p_attribute>|is;
	}
	$_IN_TMP03=~s|<123p|<p|igs;



	my $li_attribute = "";
	while($_IN_TMP03=~m/<li ([^>]+)>/is)
	{
		$li_attribute = $1;
		
		$li_attribute=~s| xml:lang=\"en-US\"||igs;
		$li_attribute=~s|class=\"(.*) ([^"]+)\"|class=\"$1"|igs;

		$_IN_TMP03=~s|<li ([^>]+)>|<123li $li_attribute>|is;
	}
	$_IN_TMP03=~s|<123li|<li|igs;
	$_IN_TMP03=~s|<p class=\"([^"]+)\"\/>\n?||igs;
	$_IN_TMP03=~s|<div ([^>]+)>\n?||igs;
	$_IN_TMP03=~s|<\/div>\n?||igs;
	$_IN_TMP03=~s|<img ([^>]+)>|<img id=\"img-c0*f00*\" src=\"../images/c0*f00*.png\" alt=\"images\"\/>|igs;

	$_IN_TMP03=~s|<td ([^>]+)>|<td valign="top">|igs;
	$_IN_TMP03=~s|<table ([^>]+)>|<table id="**">|igs;
	$_IN_TMP03=~s|<tbody>\n?||igs;
	$_IN_TMP03=~s|<\/tbody>\n?||igs;
	$_IN_TMP03=~s|\n?<\/td>|<\/td>|igs;
	$_IN_TMP03=~s|<td valign="top">\n?|<td valign="top">|igs;

	#$_IN_TMP03=~s| <\/span_1>|</span_1> |igs;
	$_IN_TMP03=~s|\n<\/p>|</p>|igs;
	$_IN_TMP03=~s|<p ([^>]+)>\n|<p $1>|igs;
	
	#creating directory for output
	mkdir $output_path, 0755;
	#FINAL OUT
	open (OUT_HTM_FILE, '>', "$output_file_with_path") or die "Error: could not out file $output_file_with_path$!\n";
	if(-d $output_path)
	{
		print OUT_HTM_FILE "$_IN_TMP03";
	}
	close(OUT_HTM_FILE);
	###########-END- IN TMP03 OUT FINAL ########################

	#unlink($inout_temp_with_path_01);
	#unlink($inout_temp_with_path_02);
	#unlink($inout_temp_with_path_03);

	$_IN_TEMPLATE=~s|<asset id=\"([^"]+)\">(.*?)<\/asset>|<123asset id=\"$asset_id\">$asset_content<\/asset123>|is;
}
$_IN_TEMPLATE=~s|<123asset|<asset|igs;
$_IN_TEMPLATE=~s|<\/asset123>|<\/asset>|igs;
print "\n- - - - - - - - - - - - -\n";
print "\nPlease check element starting with <vpro in out files.\n";
close(OUT_ERROR);