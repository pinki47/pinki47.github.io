rename
indesign_span_clineup.txt to indesign_span_clineup.exe


c:\exepath>indesign_span_clineup.exe c:\santosh\clineup\epub_indesign_clineup\template.xml

then press enter

Note:-
Please check in template.css span attribute for space before colon like
font-style : italic;
font-weight : bold;

put exactly in template span_attribute value
<span_attribute value="font-weight :"/>

hrere i am searching for 
for example
font-style : italic;
$span_attribute_value ([^;]+)\;

The out folder is must be there.

Please provide me the feedback and suggetions for improve the indesing_span_clineup process.